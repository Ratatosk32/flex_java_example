const origin =// "json=" + encodeURI(JSON.stringify(
    [
        {
            Institution: "Institution1",
            HowRegistered: "3rd party",
            WhereHeld: "stock brokers",
            CurrentCount: '1100',
            PrevCount: '23423',
            CurrentValue: '23423',
            PrevValue: '0'
        },
        {
            Institution: "Institution2",
            HowRegistered: "Custodian",
            WhereHeld: "stack holder",
            CurrentCount: '232',
            PrevCount: '',
            CurrentValue: '234',
            PrevValue: '546'
        },
        {
            Institution: "Institution3",
            HowRegistered: "3rd party",
            WhereHeld: "valuation asset",
            CurrentCount: '123',
            PrevCount: '0',
            CurrentValue: '234',
            PrevValue: '2342'
        }, {
        Institution: "Institution1",
        HowRegistered: "3rd party",
        WhereHeld: "stock brokers",
        CurrentCount: '1100',
        PrevCount: '23423',
        CurrentValue: '23423',
        PrevValue: '0'
    },
        {
            Institution: "Institution2",
            HowRegistered: "Custodian",
            WhereHeld: "stack holder",
            CurrentCount: '232',
            PrevCount: '',
            CurrentValue: '234',
            PrevValue: '546'
        },
        {
            Institution: "Institution3",
            HowRegistered: "3rd party",
            WhereHeld: "valuation asset",
            CurrentCount: '123',
            PrevCount: '0',
            CurrentValue: '234',
            PrevValue: '2342'
        }, {
        Institution: "Institution1",
        HowRegistered: "3rd party",
        WhereHeld: "stock brokers",
        CurrentCount: '1100',
        PrevCount: '23423',
        CurrentValue: '23423',
        PrevValue: '0'
    },
        {
            Institution: "Institution2",
            HowRegistered: "Custodian",
            WhereHeld: "stack holder",
            CurrentCount: '232',
            PrevCount: '',
            CurrentValue: '234',
            PrevValue: '546'
        },
        {
            Institution: "Institution3",
            HowRegistered: "3rd party",
            WhereHeld: "valuation asset",
            CurrentCount: '123',
            PrevCount: '0',
            CurrentValue: '234',
            PrevValue: '2342'
        }, {
        Institution: "Institution1",
        HowRegistered: "3rd party",
        WhereHeld: "stock brokers",
        CurrentCount: '1100',
        PrevCount: '23423',
        CurrentValue: '23423',
        PrevValue: '0'
    },
        {
            Institution: "Institution2",
            HowRegistered: "Custodian",
            WhereHeld: "stack holder",
            CurrentCount: '232',
            PrevCount: '',
            CurrentValue: '234',
            PrevValue: '546'
        },
        {
            Institution: "Institution3",
            HowRegistered: "3rd party",
            WhereHeld: "valuation asset",
            CurrentCount: '123',
            PrevCount: '0',
            CurrentValue: '234',
            PrevValue: '2342'
        }, {
        Institution: "Institution1",
        HowRegistered: "3rd party",
        WhereHeld: "stock brokers",
        CurrentCount: '1100',
        PrevCount: '23423',
        CurrentValue: '23423',
        PrevValue: '0'
    },
        {
            Institution: "Institution2",
            HowRegistered: "Custodian",
            WhereHeld: "stack holder",
            CurrentCount: '232',
            PrevCount: '',
            CurrentValue: '234',
            PrevValue: '546'
        },
        {
            Institution: "Institution3",
            HowRegistered: "3rd party",
            WhereHeld: "valuation asset",
            CurrentCount: '123',
            PrevCount: '0',
            CurrentValue: '234',
            PrevValue: '2342'
        }, {
        Institution: "Institution1",
        HowRegistered: "3rd party",
        WhereHeld: "stock brokers",
        CurrentCount: '1100',
        PrevCount: '23423',
        CurrentValue: '23423',
        PrevValue: '0'
    },
        {
            Institution: "Institution2",
            HowRegistered: "Custodian",
            WhereHeld: "stack holder",
            CurrentCount: '232',
            PrevCount: '',
            CurrentValue: '234',
            PrevValue: '546'
        },
        {
            Institution: "Institution3",
            HowRegistered: "3rd party",
            WhereHeld: "valuation asset",
            CurrentCount: '123',
            PrevCount: '0',
            CurrentValue: '234',
            PrevValue: '2342'
        },
        {
            Institution: "Institution4",
            HowRegistered: "3rd party",
            WhereHeld: "client money",
            CurrentCount: '345',
            PrevCount: '25',
            CurrentValue: '2343',
            PrevValue: '2343'
        }


    ];